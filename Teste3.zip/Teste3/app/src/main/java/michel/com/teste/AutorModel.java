package michel.com.teste;

public class AutorModel {

    private String nome;
    private String titulo;
    private String editora;

    public AutorModel(String nome, String titulo, String editora){
        this.nome = nome;
        this.titulo = titulo;
        this.editora = editora;
    }

    public String getNome() {
        return nome;
    }

    public void setAutor(String autor) {
        this.nome = autor;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getEditora() {
        return editora;
    }

    public void setEditora(String editora) {
        this.editora = editora;
    }


}
