package michel.com.teste;

import static org.junit.Assert.*;

public class MainActivityTest {

}